"""COA Analyzer package for analyzing Certificates of Analysis documents."""

__version__ = "0.1.0" 